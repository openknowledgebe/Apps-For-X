<div class="metabox-holder">
        <div class="postbox">
<h3>Premium Feature</h3>
          <div class="inside">
          <div class="padding">
            <h1 style="color:#F00; text-align:center;">This feature is included in the premium version of Event Espresso. </h1>
            <h1 style=" text-align:center;">Upgrade now!</h1>
<table class="pricing" cellpadding="0" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <td class="colfirst" style="width: 175px;"><h2>Compare &amp; Purchase</h2></td>
                  <td style="width: 146px;" align="center"><!--<h2><strong>$59.95</strong></h2> --></td>
                  <td class="collast" style="width: 137px;" align="center"><!--<h2><strong>$199.95</strong></h2> --></td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="colfirst"></td>
                  <td align="center"><strong>1 Site Support License </strong></td>
                  <td class="collast" align="center"><strong>5 Site</strong><strong> Support License</strong></td>
                </tr>
                <tr>
                  <td class="colfirst"><span class="row_title"><a title="Customized Online Event Registration" href="http://eventespresso.com/features/custom-post-types-events/">Custom Post Types</a></span></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><span class="row_title"><a title="Customized Online Event Registration" href="http://eventespresso.com/features/custom-email-manager/">Reusable Email Templates</a></span></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><span class="row_title"><a title="Manual Event Registration" href="http://eventespresso.com/features/manual-registration/">Manual Registration</a></span></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><a title="Wordpress Event Management Plugin" href="http://eventespresso.com/features/event-management/"><span class="row_title">Event Management</span></a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><span class="row_title"><a title="Customized Online Event Registration" href="http://eventespresso.com/overview/customizable-event-listings">Customizable Online Registration</a></span></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><span class="row_title"><a title="Attendee Event Management" href="http://eventespresso.com/features/attendee-management/">Attendee Management</a></span></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><span class="row_title"><a title="Customizable Design Event Editor" href="http://eventespresso.com/overview/wysiwyg-event-editor">WYSIWYG Editor</a></span></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><a title="Authorize.net Event Registration" href="http://eventespresso.com/features/authorize-net-payment-gateway/"><span class="row_title">Authorize.net Gateway</span></a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><a title="PayPal Event Registration" href="http://eventespresso.com/features/paypal-payment-gateway/"><span class="row_title">Paypal Gateway</span></a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><a title="Multiple Pricing of Events WordPress Plugin" href="http://eventespresso.com/features/multiple-pricing-options/"><span class="row_title">Multiple Pricing Options</span></a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><a title="Wordpress Event Manager Promotion Codes" href="http://eventespresso.com/features/promotion-codes/"><span class="row_title">Promotion Codes</span></a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><a title="Wordpress Event Manager Invoice Payment System" href="http://eventespresso.com/features/invoice/"><span class="row_title">Invoicing</span></a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"><a title="Event Calendar" href="http://eventespresso.com/features/event-calendar/"><span class="row_title">Event Calendar</span></a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="row_title"><a href="http://eventespresso.com/features/customized-confirmation-emails/">Automated Emails</a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="row_title"><a title="Wordpress Event Manager Attendee Profiles Plugin" href="http://eventespresso.com/features/attendee-profiles/">Attendee Profiles</a></td>
                  <td align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                  <td class="collast" align="center"><img src="http://s3.amazonaws.com/espresso-site/images/yes.png" alt=""></td>
                </tr>
                <tr>
                  <td class="colfirst"></td>
                  <td align="center"></td>
                  <td class="collast" align="center"></td>
                </tr>
                <tr>
                  <td class="colfirst"><p>&nbsp;</p></td>
                  <td align="center"><div>
                      <p><a href="http://eventespresso.com/download/basic/">More Information</a></p>
                      <p><a href="https://www.e-junkie.com/ecom/gb.php?c=cart&amp;i=ESPRESSO1&amp;cl=113214&amp;ejc=2" target="ej_ejc" class="ec_ejc_thkbx" onclick="javascript:return EJEJC_lc(this);"><img src="http://eventespresso.com/wp-content/uploads/2010/08/add-to-cart-small.gif" alt="Add to Cart" border="0"></a></p>
                    </div></td>
                  <td class="collast" align="center"><div>
                      <p><a href="http://eventespresso.com/download/developer/">More Information</a></p>
                      <p><a href="https://www.e-junkie.com/ecom/gb.php?c=cart&amp;i=ESPRESSO5&amp;cl=113214&amp;ejc=2" target="ej_ejc" class="ec_ejc_thkbx" onclick="javascript:return EJEJC_lc(this);"><img src="http://eventespresso.com/wp-content/uploads/2010/08/add-to-cart-small.gif" alt="Add to Cart" border="0"></a></p>
                    </div></td>
                </tr>
              </tbody>
            </table>
            <p>Before downloading, please be sure your server <a href="http://eventespresso.com/requirements/">meets the requirements</a>.</p>
            <p>Non-profit organizations may request a discounted price for the "1 Site Support License" by completing the <a href="http://eventespresso.com/non-profit-discounts/">Non-profit Application Form</a>.</p>
            </div>
          </div>
          </div>
      </div>
            <script type="text/javascript">// <![CDATA[
      function EJEJC_lc(th) { return false; }
// ]]></script>
<script src="http://www.e-junkie.com/ecom/box.js" type="text/javascript"></script>
